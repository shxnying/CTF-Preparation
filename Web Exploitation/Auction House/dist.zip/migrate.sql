DROP TABLE IF EXISTS users;

CREATE TABLE IF NOT EXISTS users (
    id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(255) NOT NULL UNIQUE,
    wealth DOUBLE NOT NULL,
    expiredTime INTEGER NOT NULL
);

DROP TABLE IF EXISTS assets;

CREATE TABLE IF NOT EXISTS assets (
    id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    asset_name VARCHAR(255) NOT NULL,
    owner_name VARCHAR(255) NOT NULL,
    FOREIGN KEY(owner_name) REFERENCES users(username) ON DELETE CASCADE
);

DROP TABLE IF EXISTS bidders;

CREATE TABLE IF NOT EXISTS bidders (
    id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    bidder_name VARCHAR(255) NOT NULL,
    bid_price DOUBLE NOT NULL
);

INSERT INTO
    bidders (bidder_name, bid_price)
VALUES
    ('Mark', 10);

INSERT INTO
    bidders (bidder_name, bid_price)
VALUES
    ('Jacob', 20);

INSERT INTO
    bidders (bidder_name, bid_price)
VALUES
    ('Larry', 38);

DROP TABLE IF EXISTS products;

CREATE TABLE IF NOT EXISTS products (
    id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    product_name VARCHAR(255) NOT NULL,
    fullname VARCHAR(255) NOT NULL,
    desc VARCHAR(255) NOT NULL,
    price DOUBLE NOT NULL,
    image_path VARCHAR(255) NOT NULL
);

INSERT INTO
    products (product_name, fullname, desc, price, image_path)
VALUES
    (
        'cookie',
        'Clover''s Cookies',
        'Aunt Clover made one of the best cookies before she went off to start her own restaurant. This cookie is preserved for 5 years. We believe it''s still fresh.',
        20,
        '/images/shop_cookie.png'
    );

INSERT INTO
    products (product_name, fullname, desc, price, image_path)
VALUES
    (
        'calculator',
        'Carter''s Calculator',
        'Carter is one of the greatest mathematicians. With this calculator, you can solve nearly all mathemtical equations, even breaking encryptions!',
        30,
        '/images/shop_calculator.png'
    );

INSERT INTO
    products (product_name, fullname, desc, price, image_path)
VALUES
    (
        'computer',
        'Caster''s Computer',
        'Caster has championed in more than 10 CTFs in the past 3 years. Now that he''s retiring, he''s selling his computer at an affordable price!',
        100,
        '/images/shop_computer.svg'
    );