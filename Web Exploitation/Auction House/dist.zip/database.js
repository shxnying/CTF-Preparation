const sqlite = require('sqlite-async');
const fs = require('fs');

class Database {
	constructor(db_file) {
		this.db_file = db_file;
		this.db = undefined;
	}
	
	async connect() {
		this.db = await sqlite.open(this.db_file);
		console.log('Connected to database');
	}

	async migrate() {
		var sql_stmt = fs.readFileSync('./migrate.sql').toString()
		return this.db.exec(`${sql_stmt}`);
	}

	async registerUser(username) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare(`INSERT INTO users (username, wealth, expiredTime) VALUES ( ?, 0.00, ${Date.now()+1000*60*60});`);
				await stmt.run(username);
				let stmt2 = await this.db.prepare('INSERT INTO assets (asset_name, owner_name) VALUES ("watch", ?);');
				resolve((await stmt2.run(username)));
			} catch(e) {
				reject(e);
			}
		});
	}

	async resetUser(username) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('UPDATE users SET wealth=0 WHERE username=?;');
				await stmt.run(username);
				let stmt2 = await this.db.prepare('DELETE FROM assets WHERE owner_name = ?')
				await stmt2.run(username);
				let stmt3 = await this.db.prepare('INSERT INTO assets (asset_name, owner_name) VALUES ("watch", ?);');
				resolve((await stmt3.run(username)));
			} catch(e) {
				reject(e);
			}
		});
	}

	async getUser(user) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('SELECT * FROM users WHERE username = ?');
				resolve(await stmt.get(user));
			} catch(e) {
				reject(e);
			}
		});
	}

	async removeUser(user){
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('DELETE FROM users WHERE expiredTime > UNIXEPOCH();');
				resolve(await stmt.get(user));
			} catch(e) {
				reject(e);
			}
		});
	}

	async setWealth(username, wealth) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('UPDATE users SET wealth = ? WHERE username = ?');
				resolve(await stmt.get(wealth, username));
			} catch(e) {
				reject(e);
			}
		});
	}

	async getProduct(product) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('SELECT * FROM products where product_name = ?;');
				resolve(await stmt.get(product));
			} catch(e) {
				reject(e);
			}
		});
	}

	async getAssets() {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('SELECT * FROM assets;');
				resolve(await stmt.all());
			} catch(e) {
				reject(e);
			}
		});
	}

	async getProducts(){
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('SELECT * FROM products;');
				resolve(await stmt.all());
			} catch(e) {
				reject(e);
			}
		});
	}

	async getProductValue(product_name) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('SELECT price FROM products WHERE product_name=?;');
				resolve(await stmt.get(product_name));
			} catch(e) {
				reject(e);
			}
		});
	}

	async getAssetsFromUser(username) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('SELECT * FROM assets WHERE owner_name=?;');
				resolve(await stmt.all(username));
			} catch(e) {
				reject(e);
			}
		});
	}

	async getAsset(asset_name, username) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('SELECT * FROM assets WHERE asset_name=? AND owner_name=?;');
				resolve(await stmt.get(asset_name, username));
			} catch(e) {
				reject(e);
			}
		});
	}

	async addWealth(username, product_value) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('UPDATE users SET wealth = wealth + ? WHERE username = ?');
				resolve((await stmt.run(product_value, username)));
			} catch(e) {
				reject(e);
			}
		});
	}

	async removeAsset(username, asset_name) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('DELETE FROM assets WHERE owner_name = ? AND asset_name = ?');
				resolve((await stmt.run(username, asset_name)));
			} catch(e) {
				reject(e);
			}
		});
	}

	async getBidders(){
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('SELECT bidder_name, bid_price FROM bidders;');
				resolve(await stmt.all());
			} catch(e) {
				reject(e);
			}
		});
	}

	async getBidder(bidder_name) {
		return new Promise(async (resolve, reject) => {
			try {
				let stmt = await this.db.prepare('SELECT * FROM bidders WHERE bidder_name = ?');
				resolve(await stmt.get(bidder_name));
			} catch(e) {
				reject(e);
			}
		});
	}

}


module.exports = Database;