const express = require('express')
const cors = require('cors')
const favicon = require('serve-favicon')	
const cookieParser = require('cookie-parser');
const fs = require('fs');
const AuthManager = require('./middleware/auth')
const app = express()

const Database = require('./database');
const port = process.env.PORT || 3102;
const db = new Database('auction_room.db');


// add middleware
app.use(express.urlencoded({ extended: true }))
app.use(cors())
app.use(express.json())
app.use(cookieParser())
app.use(favicon(__dirname + '/public/images/favicon.ico'))
app.use(express.static('public'))
app.set('view engine', 'ejs');


(async () => {
	await db.connect();
	await db.migrate();
	app.listen(port, () => {
		console.log(`Listening at ${port}`)
	})
})();

// Remove expired users from database every 10 minutes. Not important
setInterval(() => {
	try{
		console.log("remove user");
		db.removeUser();
	}
	catch(e){
		console.log(e);
	}
}, 1000 * 60 * 10);


// Routes
app.get('/', AuthManager.authValidator, async (req, res) => {
	const username = req.body.username;
	let user = await db.getUser(username);
	if (!user){
		await db.registerUser(username);
		user = await db.getUser(username);
	}
	let assets = await db.getAssetsFromUser(username);
	return res.render('index', {assets: assets, wealth: user.wealth});
})

const response = (body, wealth) => ({ message: body, wealth: wealth });

app.get('/auction/home', AuthManager.authValidator, async (req, res) => {
	const username = req.body.username;
	let user = await db.getUser(username);
	if (!user) {
		await db.registerUser(username);
		user = await db.getUser(username);
	}
	let assets = await db.getAssetsFromUser(username);
	let bidders = await db.getBidders();
	return res.render('auction_home', {assets: assets, wealth: user.wealth, bidders: bidders});
})

app.post('/auction/sell', AuthManager.authValidator, async (req, res) => {
  const username = req.body.username;
	const bidder_name = req.body.bidder_name;
  try {
    let user = await db.getUser(username);
    if (!user) {
      await db.registerUser(username);
      user = await db.getUser(username);
    }
    const { asset_name } = req.body;
    if (asset_name) {
      const asset = await db.getAsset(asset_name, user.username);
      if (asset) {
				let bidder = await db.getBidder(bidder_name);
				if(bidder === undefined){
					return res.send(response("Fail: bidder does not exist", user.wealth));	
				}
				let price = bidder.bid_price;
        await db.addWealth(user.username, price);
        await db.removeAsset(user.username, asset_name);
				user = await db.getUser(user.username);
        return res.send(response(`Success: User ${user.username} gained ${price} by selling ${asset_name}`, user.wealth));
      } else {
        return res.send(response("Fail: Asset does not exist", user.wealth));
      }
    } else {
      return res.status(401).send(response("Fail: No such asset", user.wealth));
    }
  } catch (e) {
    console.log(e);
    return res.status(500).send(response("Failed to sell"));
  }
});


app.get('/shop/home', AuthManager.authValidator, async (req, res) => {
	const username = req.body.username;
	let user = await db.getUser(username);
	if (!user) {
		await db.registerUser(username);
		user = await db.getUser(username);
	}
	let products = await db.getProducts();
	return res.render('purchase_home', {wealth: user.wealth, products: products});
})


app.post('/shop/buy', AuthManager.authValidator, (req, res) => {
	const username = req.body.username;
	return db.getUser(username)
		.then(async user => {
			if(user != undefined){
				const { item_name } = req.body;
				return db.getProduct(item_name)
					.then(product_item => {
						if(product_item == undefined) return res.send(response("Fail: Missing item code", user.wealth))
						if(product_item.price <= user.wealth){
							newWealth = parseFloat(user.wealth - product_item.price).toFixed(2);
							return db.setWealth(req.body.username, newWealth)
								.then(async () => {
									user = await db.getUser(user.username);
									if(product_item.product_name == 'computer') return res.json({
										flag: fs.readFileSync('./flag.txt').toString(),
										message: `Success: Purchased ${product_item.item_name} worth ${product_item.price}`,
										wealth: user.wealth
									})
									else return res.send(response(`Success: Purchased ${product_item.item_name} worth ${product_item.price}`, user.wealth))
								})
						}
						return res.status(403).send(response("Fail: Insufficient balance", user.wealth));
					})
			}
			return res.status(401).send(response('Fail: Missing body'))
		})
})

app.get('/reset', AuthManager.authValidator, (req, res) => {
	const username = req.body.username;
	return db.getUser(username)
		.then(async user => {
			if(user != undefined){
				await db.resetUser(username);
				return res.redirect('/');
			}
			else{
				return res.status(403).send(response("Fail: No such user"));
			}
		})
})

app.all('*', (req, res) => {
	res.redirect('/')
});

/* 
Image Credits
favicon.ico: https://www.clipartmax.com/middle/m2H7i8N4b1i8K9d3_home-%E2%80%9Dalternate-house-emoji-png/
Cookie: http://clipart-library.com/cartoon-pictures-of-cookies.html
Calculator: https://commons.wikimedia.org/wiki/File:Calculator_Flat_Icon_Vector.svg
Computer: https://commons.wikimedia.org/wiki/File:Black_laptop.svg
*/
