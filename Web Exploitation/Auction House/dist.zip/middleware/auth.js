const crypto = require('crypto')
const jwt = require('jsonwebtoken')
const { v4: uuid } = require("uuid");
const ACCESS_TOKEN_SECRET = crypto.randomBytes(64).toString('hex');

const authValidator = async (req, res, next) => {
  try {
    const token = req.cookies.session;
    if (!token || token === null) {
      const username = uuid();
      const token = await jwt.sign({ username }, ACCESS_TOKEN_SECRET);
      res.cookie('session', token, { maxAge: 60000*60 });   // persist user session for 15 minutes
      return res.redirect('/');
    }
    jwt.verify(token, ACCESS_TOKEN_SECRET, async (err, result) => {
      if (err) {
        const username = uuid();
        const token = await jwt.sign({ username }, ACCESS_TOKEN_SECRET);
        res.cookie('session', token, { maxAge: 60000*60 });   // persist user session for 15 minutes
        res.redirect('/');
      }
      else {
        if (req.body === undefined) {
          req.body = {};
        }
        req.body['username'] = result.username;
        next();
      }
    })
  }
  catch (e) {
    console.log(e);
    return res.status(500).send('Fail: Internal server error');
  }
}

module.exports = {
  authValidator
}